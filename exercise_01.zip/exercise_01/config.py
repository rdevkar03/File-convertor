import os
import tempfile

APP_TITLE = "Advanced File Format Converter"
APP_ICON = "🔄"

MAX_UPLOAD_SIZE_MB = 200
TEMP_DIR = os.path.join(tempfile.gettempdir(), "file_converter")
HISTORY_DB_PATH = os.path.join(os.path.dirname(__file__), "data", "history.db")

SUPPORTED_FORMATS = {
    "pdf": "PDF Document",
    "docx": "Word Document",
    "txt": "Plain Text",
    "html": "HTML Document",
    "md": "Markdown",
    "xlsx": "Excel Spreadsheet",
    "csv": "CSV File",
    "json": "JSON File",
}

FORMAT_EXTENSIONS = {fmt: f".{fmt}" for fmt in SUPPORTED_FORMATS}

os.makedirs(TEMP_DIR, exist_ok=True)
os.makedirs(os.path.dirname(HISTORY_DB_PATH), exist_ok=True)
