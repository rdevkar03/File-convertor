"""Batch conversion UI component: multi-file upload, progress, and ZIP download."""

import io
import os
import time
import zipfile
from typing import Any, Dict, List

import streamlit as st

from converters import get_converter
from services import history as hist_service
from services.metadata import extract_metadata
from config import SUPPORTED_FORMATS


def render_batch_tab(source_fmt: str, target_fmt: str, options: Dict[str, Any]):
    """Render the batch conversion tab with multi-file upload and progress."""
    st.subheader("Batch Conversion")
    st.caption(
        f"Upload multiple **{source_fmt.upper()}** files to convert them all to "
        f"**{target_fmt.upper()}**."
    )

    # File extension for upload filter
    ext = f".{source_fmt}"
    uploaded_files = st.file_uploader(
        "Upload files",
        type=[source_fmt],
        accept_multiple_files=True,
        key="batch_uploader",
    )

    if not uploaded_files:
        st.info("Upload one or more files to begin batch conversion.")
        return

    st.write(f"**{len(uploaded_files)}** file(s) ready for conversion.")

    # Preview summary
    with st.expander("File Summary", expanded=False):
        for f in uploaded_files:
            file_bytes = f.read()
            f.seek(0)
            meta = extract_metadata(file_bytes, f.name)
            st.text(f"  {f.name} — {meta['size_human']}")

    # Convert button
    if st.button("Convert All", type="primary", key="batch_convert_btn"):
        converter = get_converter(source_fmt, target_fmt)
        if not converter:
            st.error(f"No converter found for {source_fmt} -> {target_fmt}")
            return

        progress_bar = st.progress(0, text="Starting batch conversion...")
        status_container = st.container()
        results: List[Dict] = []
        errors: List[str] = []

        for i, uploaded_file in enumerate(uploaded_files):
            file_bytes = uploaded_file.read()
            uploaded_file.seek(0)
            filename = uploaded_file.name
            base_name = os.path.splitext(filename)[0]
            output_name = f"{base_name}.{target_fmt}"

            progress_bar.progress(
                (i) / len(uploaded_files),
                text=f"Converting {filename} ({i + 1}/{len(uploaded_files)})...",
            )

            start_time = time.time()
            try:
                result_bytes = converter.convert(
                    file_bytes, source_fmt, target_fmt, options
                )
                duration_ms = int((time.time() - start_time) * 1000)

                results.append({
                    "name": output_name,
                    "data": result_bytes,
                    "source_name": filename,
                    "source_size": len(file_bytes),
                    "result_size": len(result_bytes),
                })

                hist_service.record_conversion(
                    source_filename=filename,
                    source_format=source_fmt,
                    target_format=target_fmt,
                    source_size=len(file_bytes),
                    result_size=len(result_bytes),
                    options=options,
                    status="success",
                    duration_ms=duration_ms,
                )

                with status_container:
                    st.success(f"Converted: {filename} -> {output_name}")

            except Exception as e:
                duration_ms = int((time.time() - start_time) * 1000)
                errors.append(f"{filename}: {e}")

                hist_service.record_conversion(
                    source_filename=filename,
                    source_format=source_fmt,
                    target_format=target_fmt,
                    source_size=len(file_bytes),
                    status="error",
                    error_message=str(e),
                    duration_ms=duration_ms,
                )

                with status_container:
                    st.error(f"Failed: {filename} — {e}")

        progress_bar.progress(1.0, text="Batch conversion complete!")

        # Summary
        st.divider()
        col1, col2, col3 = st.columns(3)
        col1.metric("Total Files", len(uploaded_files))
        col2.metric("Successful", len(results))
        col3.metric("Failed", len(errors))

        # Download as ZIP
        if results:
            zip_buffer = io.BytesIO()
            with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
                for item in results:
                    zf.writestr(item["name"], item["data"])
            zip_buffer.seek(0)

            st.download_button(
                label=f"Download All ({len(results)} files) as ZIP",
                data=zip_buffer.getvalue(),
                file_name=f"converted_{source_fmt}_to_{target_fmt}.zip",
                mime="application/zip",
                type="primary",
            )

        # Individual downloads
        if results:
            with st.expander("Download Individual Files"):
                for item in results:
                    st.download_button(
                        label=f"Download {item['name']}",
                        data=item["data"],
                        file_name=item["name"],
                        key=f"dl_{item['name']}",
                    )
