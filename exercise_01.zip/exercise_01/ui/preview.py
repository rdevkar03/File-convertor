"""File preview UI component: before/after preview rendering."""

import streamlit as st
from converters import get_converter
from services.metadata import extract_metadata


def render_preview(
    file_bytes: bytes, filename: str, fmt: str, label: str = "Preview"
):
    """Render a file preview with metadata in an expander."""
    with st.expander(f"{label}: {filename}", expanded=True):
        # Metadata table
        meta = extract_metadata(file_bytes, filename)
        _render_metadata(meta)

        st.divider()

        # Content preview
        converter = _find_any_converter(fmt)
        if converter:
            try:
                preview_text = converter.preview(file_bytes, fmt)
                if fmt == "html":
                    st.code(preview_text[:2000], language="html")
                elif fmt in ("json",):
                    st.code(preview_text[:2000], language="json")
                elif fmt in ("md",):
                    st.markdown(preview_text[:2000])
                else:
                    st.text(preview_text[:2000])
            except Exception as e:
                st.warning(f"Preview generation failed: {e}")
        else:
            # Fallback: try to decode as text
            try:
                text = file_bytes.decode("utf-8", errors="replace")
                st.text(text[:2000])
            except Exception:
                st.info("Binary file — preview not available.")


def render_comparison(
    source_bytes: bytes,
    source_name: str,
    source_fmt: str,
    result_bytes: bytes,
    result_name: str,
    result_fmt: str,
):
    """Render a side-by-side before/after comparison."""
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Source")
        render_preview(source_bytes, source_name, source_fmt, label="Original")

    with col2:
        st.subheader("Converted")
        render_preview(result_bytes, result_name, result_fmt, label="Result")


def _render_metadata(meta: dict):
    """Display metadata as a compact info grid."""
    display_keys = [
        ("format", "Format"),
        ("size_human", "Size"),
        ("page_count", "Pages"),
        ("word_count", "Words"),
        ("line_count", "Lines"),
        ("paragraph_count", "Paragraphs"),
        ("sheet_count", "Sheets"),
        ("sheet_names", "Sheet Names"),
        ("encoding", "Encoding"),
        ("record_count", "Records"),
        ("table_count", "Tables"),
        ("author", "Author"),
        ("title", "Title"),
    ]
    items = []
    for key, label in display_keys:
        val = meta.get(key)
        if val is not None:
            if isinstance(val, list):
                val = ", ".join(str(v) for v in val[:5])
            items.append(f"**{label}:** {val}")

    if items:
        # Display as a flowing markdown line
        st.markdown(" &nbsp;|&nbsp; ".join(items))


def _find_any_converter(fmt: str):
    """Find any converter that can preview the given format."""
    from converters import REGISTRY

    for (src, tgt), converter in REGISTRY.items():
        if src == fmt or tgt == fmt:
            return converter
    return None
