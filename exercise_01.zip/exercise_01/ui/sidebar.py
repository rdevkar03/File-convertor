"""Sidebar UI component: format selector, conversion options, and quick stats."""

import streamlit as st
from converters import get_all_source_formats, get_supported_targets, REGISTRY
from config import SUPPORTED_FORMATS
from services.compression import get_options_for_conversion, build_option_widgets
from services import history as hist_service


def render_sidebar():
    """Render the sidebar with format selection, options, and stats."""
    with st.sidebar:
        st.header("Conversion Settings")

        # --- Format Selection ---
        source_formats = get_all_source_formats()
        if not source_formats:
            st.error("No converters loaded. Check the converters/ directory.")
            return None, None, {}

        source_labels = [
            f"{fmt.upper()} - {SUPPORTED_FORMATS.get(fmt, fmt)}"
            for fmt in source_formats
        ]
        selected_source_idx = st.selectbox(
            "Source Format",
            range(len(source_formats)),
            format_func=lambda i: source_labels[i],
            key="sidebar_source_fmt",
        )
        source_fmt = source_formats[selected_source_idx]

        target_formats = get_supported_targets(source_fmt)
        target_labels = [
            f"{fmt.upper()} - {SUPPORTED_FORMATS.get(fmt, fmt)}"
            for fmt in target_formats
        ]
        selected_target_idx = st.selectbox(
            "Target Format",
            range(len(target_formats)),
            format_func=lambda i: target_labels[i],
            key="sidebar_target_fmt",
        )
        target_fmt = target_formats[selected_target_idx]

        st.divider()

        # --- Conversion Options ---
        st.subheader("Options")
        options_spec = get_options_for_conversion(source_fmt, target_fmt)
        if options_spec:
            options = build_option_widgets(options_spec, prefix="sidebar")
        else:
            st.caption("No configurable options for this conversion.")
            options = {}

        st.divider()

        # --- Quick Stats ---
        st.subheader("Session Stats")
        try:
            stats = hist_service.get_stats()
            col1, col2 = st.columns(2)
            col1.metric("Total", stats["total_conversions"])
            col2.metric("Success Rate", stats["success_rate"])

            if stats["popular_conversions"]:
                st.caption("Most used:")
                for item in stats["popular_conversions"][:3]:
                    st.text(f"  {item['conversion']} ({item['count']}x)")
        except Exception:
            st.caption("No conversion history yet.")

        st.divider()
        st.caption(f"Registered converters: {len(REGISTRY)}")

    return source_fmt, target_fmt, options
