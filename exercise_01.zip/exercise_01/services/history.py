"""SQLite-backed conversion history service."""

import sqlite3
import os
from datetime import datetime
from typing import Any, Dict, List, Optional

from config import HISTORY_DB_PATH

_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS conversion_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    source_filename TEXT NOT NULL,
    source_format TEXT NOT NULL,
    target_format TEXT NOT NULL,
    source_size INTEGER NOT NULL,
    result_size INTEGER,
    options TEXT,
    status TEXT NOT NULL DEFAULT 'success',
    error_message TEXT,
    duration_ms INTEGER
)
"""


def _get_conn() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(HISTORY_DB_PATH), exist_ok=True)
    conn = sqlite3.connect(HISTORY_DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute(_CREATE_TABLE)
    conn.commit()
    return conn


def record_conversion(
    source_filename: str,
    source_format: str,
    target_format: str,
    source_size: int,
    result_size: Optional[int] = None,
    options: Optional[Dict[str, Any]] = None,
    status: str = "success",
    error_message: Optional[str] = None,
    duration_ms: Optional[int] = None,
) -> int:
    """Record a conversion in the history database. Returns the record ID."""
    import json

    conn = _get_conn()
    cursor = conn.execute(
        """INSERT INTO conversion_history
           (timestamp, source_filename, source_format, target_format,
            source_size, result_size, options, status, error_message, duration_ms)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            datetime.now().isoformat(),
            source_filename,
            source_format,
            target_format,
            source_size,
            result_size,
            json.dumps(options) if options else None,
            status,
            error_message,
            duration_ms,
        ),
    )
    conn.commit()
    record_id = cursor.lastrowid
    conn.close()
    return record_id


def get_history(limit: int = 50, offset: int = 0) -> List[Dict[str, Any]]:
    """Get conversion history records, most recent first."""
    conn = _get_conn()
    rows = conn.execute(
        "SELECT * FROM conversion_history ORDER BY id DESC LIMIT ? OFFSET ?",
        (limit, offset),
    ).fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_history_count() -> int:
    """Get total number of history records."""
    conn = _get_conn()
    count = conn.execute("SELECT COUNT(*) FROM conversion_history").fetchone()[0]
    conn.close()
    return count


def get_stats() -> Dict[str, Any]:
    """Get aggregate statistics from conversion history."""
    conn = _get_conn()
    total = conn.execute("SELECT COUNT(*) FROM conversion_history").fetchone()[0]
    success = conn.execute(
        "SELECT COUNT(*) FROM conversion_history WHERE status='success'"
    ).fetchone()[0]
    failed = conn.execute(
        "SELECT COUNT(*) FROM conversion_history WHERE status='error'"
    ).fetchone()[0]

    popular = conn.execute(
        """SELECT source_format || ' -> ' || target_format AS conversion, COUNT(*) AS cnt
           FROM conversion_history
           GROUP BY conversion ORDER BY cnt DESC LIMIT 5"""
    ).fetchall()

    total_bytes = conn.execute(
        "SELECT COALESCE(SUM(source_size), 0) FROM conversion_history"
    ).fetchone()[0]

    conn.close()

    return {
        "total_conversions": total,
        "successful": success,
        "failed": failed,
        "success_rate": f"{(success / total * 100):.1f}%" if total > 0 else "N/A",
        "popular_conversions": [
            {"conversion": row[0], "count": row[1]} for row in popular
        ],
        "total_data_processed": _human_size(total_bytes),
    }


def clear_history() -> int:
    """Delete all history records. Returns number of records deleted."""
    conn = _get_conn()
    count = conn.execute("SELECT COUNT(*) FROM conversion_history").fetchone()[0]
    conn.execute("DELETE FROM conversion_history")
    conn.commit()
    conn.close()
    return count


def _human_size(size_bytes: int) -> str:
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"
