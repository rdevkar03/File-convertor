"""File metadata extraction service."""

import io
import os
from typing import Any, Dict

import chardet


def extract_metadata(file_bytes: bytes, filename: str) -> Dict[str, Any]:
    """Extract metadata from a file based on its format.

    Returns a dict with keys like: size, size_human, format, encoding,
    page_count, word_count, line_count, sheet_names, etc.
    """
    ext = os.path.splitext(filename)[1].lower().lstrip(".")
    size = len(file_bytes)

    meta: Dict[str, Any] = {
        "filename": filename,
        "format": ext.upper(),
        "size_bytes": size,
        "size_human": _human_size(size),
    }

    extractors = {
        "pdf": _extract_pdf_meta,
        "docx": _extract_docx_meta,
        "xlsx": _extract_xlsx_meta,
        "csv": _extract_text_meta,
        "txt": _extract_text_meta,
        "md": _extract_text_meta,
        "html": _extract_html_meta,
        "json": _extract_json_meta,
    }

    extractor = extractors.get(ext)
    if extractor:
        try:
            meta.update(extractor(file_bytes))
        except Exception as e:
            meta["extraction_error"] = str(e)

    return meta


def _human_size(size_bytes: int) -> str:
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


def _extract_pdf_meta(data: bytes) -> Dict[str, Any]:
    from PyPDF2 import PdfReader

    reader = PdfReader(io.BytesIO(data))
    info = reader.metadata or {}
    text = ""
    for page in reader.pages[:5]:
        text += (page.extract_text() or "")

    return {
        "page_count": len(reader.pages),
        "word_count": len(text.split()),
        "author": getattr(info, "author", None),
        "title": getattr(info, "title", None),
        "creator": getattr(info, "creator", None),
    }


def _extract_docx_meta(data: bytes) -> Dict[str, Any]:
    from docx import Document

    doc = Document(io.BytesIO(data))
    text = "\n".join(p.text for p in doc.paragraphs)
    core = doc.core_properties

    return {
        "paragraph_count": len(doc.paragraphs),
        "word_count": len(text.split()),
        "character_count": len(text),
        "table_count": len(doc.tables),
        "author": core.author,
        "title": core.title,
        "created": str(core.created) if core.created else None,
        "modified": str(core.modified) if core.modified else None,
    }


def _extract_xlsx_meta(data: bytes) -> Dict[str, Any]:
    from openpyxl import load_workbook

    wb = load_workbook(io.BytesIO(data), read_only=True)
    sheet_info = {}
    for name in wb.sheetnames:
        ws = wb[name]
        sheet_info[name] = {
            "max_row": ws.max_row,
            "max_column": ws.max_column,
        }
    wb.close()

    return {
        "sheet_count": len(wb.sheetnames),
        "sheet_names": wb.sheetnames,
        "sheets": sheet_info,
    }


def _extract_text_meta(data: bytes) -> Dict[str, Any]:
    detected = chardet.detect(data)
    encoding = detected.get("encoding", "utf-8") or "utf-8"
    confidence = detected.get("confidence", 0)
    text = data.decode(encoding, errors="replace")

    lines = text.split("\n")
    words = text.split()

    return {
        "encoding": encoding,
        "encoding_confidence": f"{confidence:.0%}",
        "line_count": len(lines),
        "word_count": len(words),
        "character_count": len(text),
    }


def _extract_html_meta(data: bytes) -> Dict[str, Any]:
    from bs4 import BeautifulSoup

    detected = chardet.detect(data)
    encoding = detected.get("encoding", "utf-8") or "utf-8"
    text = data.decode(encoding, errors="replace")
    soup = BeautifulSoup(text, "html.parser")

    title = soup.title.string if soup.title else None
    links = len(soup.find_all("a"))
    images = len(soup.find_all("img"))
    tables = len(soup.find_all("table"))
    headings = len(soup.find_all(["h1", "h2", "h3", "h4", "h5", "h6"]))
    body_text = soup.get_text()

    return {
        "encoding": encoding,
        "title": title,
        "link_count": links,
        "image_count": images,
        "table_count": tables,
        "heading_count": headings,
        "word_count": len(body_text.split()),
    }


def _extract_json_meta(data: bytes) -> Dict[str, Any]:
    import json

    text = data.decode("utf-8", errors="replace")
    parsed = json.loads(text)

    meta: Dict[str, Any] = {"encoding": "utf-8"}
    if isinstance(parsed, list):
        meta["type"] = "array"
        meta["record_count"] = len(parsed)
        if parsed and isinstance(parsed[0], dict):
            meta["fields"] = list(parsed[0].keys())
    elif isinstance(parsed, dict):
        meta["type"] = "object"
        meta["key_count"] = len(parsed)
        meta["keys"] = list(parsed.keys())[:20]

    return meta
