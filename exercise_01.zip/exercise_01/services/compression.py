"""Compression and quality options service.

Aggregates compression/quality options from the converter registry
and provides UI-friendly option descriptors.
"""

from typing import Any, Dict, Optional
from converters import get_converter


def get_options_for_conversion(
    source_format: str, target_format: str
) -> Dict[str, Any]:
    """Get all available conversion options for a format pair.

    Returns a dict of option descriptors suitable for building Streamlit widgets.
    """
    converter = get_converter(source_format, target_format)
    if not converter:
        return {}
    return converter.get_compression_options(source_format, target_format)


def build_option_widgets(
    options_spec: Dict[str, Any], prefix: str = ""
) -> Dict[str, Any]:
    """Build Streamlit widgets from an options spec and return the selected values.

    This function is meant to be called from within a Streamlit context.
    The prefix is used to namespace widget keys when multiple option panels exist.
    """
    import streamlit as st

    values: Dict[str, Any] = {}

    for key, spec in options_spec.items():
        widget_key = f"{prefix}_{key}" if prefix else key
        opt_type = spec.get("type", "text")
        label = spec.get("label", key)
        default = spec.get("default")

        if opt_type == "slider":
            values[key] = st.slider(
                label,
                min_value=spec.get("min", 0),
                max_value=spec.get("max", 100),
                value=default,
                key=widget_key,
            )
        elif opt_type == "select":
            choices = spec.get("choices", [])
            idx = choices.index(default) if default in choices else 0
            values[key] = st.selectbox(
                label, options=choices, index=idx, key=widget_key
            )
        elif opt_type == "checkbox":
            values[key] = st.checkbox(
                label, value=bool(default), key=widget_key
            )
        elif opt_type == "number":
            values[key] = st.number_input(
                label,
                min_value=spec.get("min", 0),
                max_value=spec.get("max", 100),
                value=default or 0,
                key=widget_key,
            )

    return values
