"""
Advanced File Format Converter
==============================
A Streamlit-based document conversion tool with plugin architecture,
batch processing, file previews, compression options, and conversion history.

Run: streamlit run app.py
"""

import os
import sys
import time

import streamlit as st

# Ensure project root is on the path so local imports work
sys.path.insert(0, os.path.dirname(__file__))

from config import APP_TITLE, APP_ICON, SUPPORTED_FORMATS
from converters import get_converter, get_all_conversions, REGISTRY
from services import history as hist_service
from services.metadata import extract_metadata
from services.compression import get_options_for_conversion, build_option_widgets
from ui.sidebar import render_sidebar
from ui.preview import render_preview, render_comparison
from ui.batch import render_batch_tab

# --- Page Config ---
st.set_page_config(
    page_title=APP_TITLE,
    page_icon=APP_ICON,
    layout="wide",
    initial_sidebar_state="expanded",
)

# --- Custom CSS ---
st.markdown(
    """
    <style>
    .main .block-container { max-width: 1200px; padding-top: 2rem; }
    .stTabs [data-baseweb="tab-list"] { gap: 8px; }
    .stTabs [data-baseweb="tab"] {
        padding: 10px 24px;
        font-weight: 500;
    }
    div[data-testid="stMetricValue"] { font-size: 1.8rem; }
    </style>
    """,
    unsafe_allow_html=True,
)

# --- Header ---
st.title(f"{APP_ICON} {APP_TITLE}")
st.caption(
    f"Convert between {len(SUPPORTED_FORMATS)} document formats with "
    f"{len(REGISTRY)} registered conversion paths. "
    "Features: batch processing, live previews, compression controls, and full history."
)

# --- Sidebar ---
source_fmt, target_fmt, options = render_sidebar()

if not source_fmt or not target_fmt:
    st.stop()

# --- Main Tabs ---
tab_single, tab_batch, tab_history = st.tabs(
    ["Single Conversion", "Batch Conversion", "Conversion History"]
)

# ==========================================
# Tab 1: Single Conversion
# ==========================================
with tab_single:
    st.subheader("Single File Conversion")
    st.caption(
        f"Converting: **{source_fmt.upper()}** → **{target_fmt.upper()}**"
    )

    uploaded_file = st.file_uploader(
        "Upload a file to convert",
        type=[source_fmt],
        key="single_uploader",
    )

    if uploaded_file:
        file_bytes = uploaded_file.read()
        uploaded_file.seek(0)

        # Source preview
        render_preview(file_bytes, uploaded_file.name, source_fmt, label="Source File")

        # Conversion options (inline for single conversion)
        with st.expander("Conversion Options", expanded=False):
            opts_spec = get_options_for_conversion(source_fmt, target_fmt)
            if opts_spec:
                inline_options = build_option_widgets(opts_spec, prefix="single")
                # Merge: sidebar options as defaults, inline overrides
                merged_options = {**options, **inline_options}
            else:
                st.caption("No configurable options for this conversion.")
                merged_options = options

        # Convert button
        col_btn, col_info = st.columns([1, 3])
        with col_btn:
            convert_clicked = st.button(
                "Convert", type="primary", key="single_convert_btn"
            )

        if convert_clicked:
            converter = get_converter(source_fmt, target_fmt)
            if not converter:
                st.error(f"No converter registered for {source_fmt} -> {target_fmt}.")
            else:
                with st.spinner("Converting..."):
                    start = time.time()
                    try:
                        result_bytes = converter.convert(
                            file_bytes, source_fmt, target_fmt, merged_options
                        )
                        duration_ms = int((time.time() - start) * 1000)

                        # Record history
                        hist_service.record_conversion(
                            source_filename=uploaded_file.name,
                            source_format=source_fmt,
                            target_format=target_fmt,
                            source_size=len(file_bytes),
                            result_size=len(result_bytes),
                            options=merged_options,
                            status="success",
                            duration_ms=duration_ms,
                        )

                        # Success message
                        st.success(
                            f"Conversion complete in {duration_ms}ms. "
                            f"Output size: {len(result_bytes):,} bytes"
                        )

                        # Result name
                        base_name = os.path.splitext(uploaded_file.name)[0]
                        result_name = f"{base_name}.{target_fmt}"

                        # Comparison preview
                        render_comparison(
                            file_bytes, uploaded_file.name, source_fmt,
                            result_bytes, result_name, target_fmt,
                        )

                        # Download
                        st.download_button(
                            label=f"Download {result_name}",
                            data=result_bytes,
                            file_name=result_name,
                            type="primary",
                            key="single_download",
                        )

                    except Exception as e:
                        duration_ms = int((time.time() - start) * 1000)
                        hist_service.record_conversion(
                            source_filename=uploaded_file.name,
                            source_format=source_fmt,
                            target_format=target_fmt,
                            source_size=len(file_bytes),
                            status="error",
                            error_message=str(e),
                            duration_ms=duration_ms,
                        )
                        st.error(f"Conversion failed: {e}")

    else:
        # Show conversion matrix when no file is uploaded
        st.info("Upload a file above to start converting.")

        with st.expander("Available Conversions", expanded=False):
            all_conversions = get_all_conversions()
            # Group by source format
            grouped: dict[str, list[str]] = {}
            for src, tgt in all_conversions:
                grouped.setdefault(src.upper(), []).append(tgt.upper())
            for src, targets in sorted(grouped.items()):
                st.markdown(f"**{src}** → {', '.join(targets)}")


# ==========================================
# Tab 2: Batch Conversion
# ==========================================
with tab_batch:
    render_batch_tab(source_fmt, target_fmt, options)


# ==========================================
# Tab 3: Conversion History
# ==========================================
with tab_history:
    st.subheader("Conversion History")

    # Stats row
    try:
        stats = hist_service.get_stats()
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Total Conversions", stats["total_conversions"])
        col2.metric("Successful", stats["successful"])
        col3.metric("Failed", stats["failed"])
        col4.metric("Data Processed", stats["total_data_processed"])

        if stats["popular_conversions"]:
            st.caption("Most popular conversions:")
            for item in stats["popular_conversions"]:
                st.text(f"  {item['conversion']}  ({item['count']} times)")
    except Exception:
        pass

    st.divider()

    # History table
    history = hist_service.get_history(limit=100)
    if history:
        import pandas as pd

        df = pd.DataFrame(history)
        display_cols = [
            "timestamp",
            "source_filename",
            "source_format",
            "target_format",
            "source_size",
            "result_size",
            "status",
            "duration_ms",
        ]
        available_cols = [c for c in display_cols if c in df.columns]
        df_display = df[available_cols].copy()

        # Format columns
        if "timestamp" in df_display.columns:
            df_display["timestamp"] = pd.to_datetime(df_display["timestamp"]).dt.strftime(
                "%Y-%m-%d %H:%M:%S"
            )
        if "source_size" in df_display.columns:
            df_display["source_size"] = df_display["source_size"].apply(
                lambda x: f"{x:,} B" if x else ""
            )
        if "result_size" in df_display.columns:
            df_display["result_size"] = df_display["result_size"].apply(
                lambda x: f"{x:,} B" if pd.notna(x) and x else ""
            )
        if "duration_ms" in df_display.columns:
            df_display["duration_ms"] = df_display["duration_ms"].apply(
                lambda x: f"{x} ms" if pd.notna(x) and x else ""
            )

        df_display.columns = [
            "Time",
            "Source File",
            "From",
            "To",
            "Input Size",
            "Output Size",
            "Status",
            "Duration",
        ][: len(available_cols)]

        st.dataframe(df_display, use_container_width=True, hide_index=True)

        # Clear history
        if st.button("Clear History", type="secondary"):
            count = hist_service.clear_history()
            st.success(f"Cleared {count} record(s).")
            st.rerun()
    else:
        st.info("No conversions recorded yet. Start converting files to build your history!")


# --- Footer ---
st.divider()
st.caption(
    "Advanced File Format Converter | "
    f"{len(REGISTRY)} conversion paths from {len(get_all_conversions())} format pairs | "
    "Plugin architecture — drop new converters in the converters/ directory"
)
