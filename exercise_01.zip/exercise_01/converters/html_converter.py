import io
from typing import Dict, List, Tuple, Any, Optional

from bs4 import BeautifulSoup
import markdown as md_lib

from .base import BaseConverter


class HtmlConverter(BaseConverter):
    """Converter for HTML documents. Supports HTML <-> TXT, HTML <-> MD."""

    def supported_conversions(self) -> List[Tuple[str, str]]:
        return [
            ("html", "txt"),
            ("html", "md"),
            ("html", "csv"),
        ]

    def convert(
        self,
        input_bytes: bytes,
        source_format: str,
        target_format: str,
        options: Optional[Dict[str, Any]] = None,
    ) -> bytes:
        options = options or {}
        key = (source_format, target_format)
        dispatch = {
            ("html", "txt"): self._html_to_txt,
            ("html", "md"): self._html_to_md,
            ("html", "csv"): self._html_to_csv,
        }
        handler = dispatch.get(key)
        if not handler:
            raise ValueError(f"Unsupported conversion: {source_format} -> {target_format}")
        return handler(input_bytes, options)

    def get_compression_options(
        self, source_format: str, target_format: str
    ) -> Dict[str, Any]:
        opts: Dict[str, Any] = {}
        opts["encoding"] = {
            "type": "select",
            "label": "Output Encoding",
            "default": "utf-8",
            "choices": ["utf-8", "ascii", "latin-1", "utf-16"],
        }
        if target_format == "txt":
            opts["preserve_links"] = {
                "type": "checkbox",
                "label": "Preserve hyperlinks as [text](url)",
                "default": False,
            }
        if target_format == "csv":
            opts["table_index"] = {
                "type": "number",
                "label": "Table index to extract (0-based)",
                "default": 0,
                "min": 0,
                "max": 50,
            }
        return opts

    def preview(self, file_bytes: bytes, fmt: str) -> str:
        if fmt == "html":
            text = file_bytes.decode("utf-8", errors="replace")
            soup = BeautifulSoup(text, "html.parser")
            title = soup.title.string if soup.title else "Untitled"
            body_text = soup.get_text(separator="\n", strip=True)
            preview = f"Title: {title}\n\n{body_text[:2500]}"
            return preview
        text = file_bytes.decode("utf-8", errors="replace")
        return text[:3000]

    # --- Private conversion methods ---

    def _html_to_txt(self, data: bytes, options: Dict) -> bytes:
        encoding = options.get("encoding", "utf-8")
        preserve_links = options.get("preserve_links", False)
        text = data.decode("utf-8", errors="replace")
        soup = BeautifulSoup(text, "html.parser")

        if preserve_links:
            for a_tag in soup.find_all("a", href=True):
                link_text = a_tag.get_text()
                href = a_tag["href"]
                a_tag.replace_with(f"[{link_text}]({href})")

        plain = soup.get_text(separator="\n")
        # Clean up excess whitespace
        lines = [line.strip() for line in plain.split("\n")]
        cleaned = "\n".join(lines)
        # Remove excessive blank lines
        while "\n\n\n" in cleaned:
            cleaned = cleaned.replace("\n\n\n", "\n\n")
        return cleaned.encode(encoding, errors="replace")

    def _html_to_md(self, data: bytes, options: Dict) -> bytes:
        encoding = options.get("encoding", "utf-8")
        text = data.decode("utf-8", errors="replace")
        soup = BeautifulSoup(text, "html.parser")

        md_lines = []
        body = soup.body or soup

        for element in body.find_all(["h1", "h2", "h3", "h4", "h5", "h6", "p", "li", "pre", "blockquote", "a", "table"]):
            tag = element.name
            content = element.get_text(strip=True)
            if not content:
                continue

            if tag == "h1":
                md_lines.append(f"# {content}\n")
            elif tag == "h2":
                md_lines.append(f"## {content}\n")
            elif tag == "h3":
                md_lines.append(f"### {content}\n")
            elif tag == "h4":
                md_lines.append(f"#### {content}\n")
            elif tag == "h5":
                md_lines.append(f"##### {content}\n")
            elif tag == "h6":
                md_lines.append(f"###### {content}\n")
            elif tag == "li":
                md_lines.append(f"- {content}")
            elif tag == "pre":
                md_lines.append(f"```\n{content}\n```\n")
            elif tag == "blockquote":
                md_lines.append(f"> {content}\n")
            elif tag == "p":
                md_lines.append(f"{content}\n")

        return "\n".join(md_lines).encode(encoding, errors="replace")

    def _html_to_csv(self, data: bytes, options: Dict) -> bytes:
        import csv

        encoding = options.get("encoding", "utf-8")
        table_index = options.get("table_index", 0)
        text = data.decode("utf-8", errors="replace")
        soup = BeautifulSoup(text, "html.parser")

        tables = soup.find_all("table")
        if not tables:
            return "No tables found in HTML".encode(encoding)
        if table_index >= len(tables):
            table_index = 0

        table = tables[table_index]
        output = io.StringIO()
        writer = csv.writer(output)

        for row in table.find_all("tr"):
            cells = row.find_all(["th", "td"])
            writer.writerow([cell.get_text(strip=True) for cell in cells])

        return output.getvalue().encode(encoding, errors="replace")
