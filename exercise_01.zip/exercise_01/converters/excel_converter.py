import io
import json
from typing import Dict, List, Tuple, Any, Optional

import pandas as pd
from openpyxl import load_workbook

from .base import BaseConverter


class ExcelConverter(BaseConverter):
    """Converter for Excel spreadsheets. Supports XLSX <-> CSV, JSON, HTML."""

    def supported_conversions(self) -> List[Tuple[str, str]]:
        return [
            ("xlsx", "csv"),
            ("xlsx", "json"),
            ("xlsx", "html"),
            ("xlsx", "txt"),
            ("csv", "xlsx"),
            ("csv", "json"),
            ("csv", "html"),
            ("json", "xlsx"),
            ("json", "csv"),
        ]

    def convert(
        self,
        input_bytes: bytes,
        source_format: str,
        target_format: str,
        options: Optional[Dict[str, Any]] = None,
    ) -> bytes:
        options = options or {}
        key = (source_format, target_format)
        dispatch = {
            ("xlsx", "csv"): self._xlsx_to_csv,
            ("xlsx", "json"): self._xlsx_to_json,
            ("xlsx", "html"): self._xlsx_to_html,
            ("xlsx", "txt"): self._xlsx_to_txt,
            ("csv", "xlsx"): self._csv_to_xlsx,
            ("csv", "json"): self._csv_to_json,
            ("csv", "html"): self._csv_to_html,
            ("json", "xlsx"): self._json_to_xlsx,
            ("json", "csv"): self._json_to_csv,
        }
        handler = dispatch.get(key)
        if not handler:
            raise ValueError(f"Unsupported conversion: {source_format} -> {target_format}")
        return handler(input_bytes, options)

    def get_compression_options(
        self, source_format: str, target_format: str
    ) -> Dict[str, Any]:
        opts: Dict[str, Any] = {}
        if source_format == "xlsx":
            opts["sheet_name"] = {
                "type": "select",
                "label": "Sheet (use 'all' for all sheets)",
                "default": "first",
                "choices": ["first", "all"],
            }
        if target_format == "csv" or source_format == "csv":
            opts["delimiter"] = {
                "type": "select",
                "label": "CSV Delimiter",
                "default": ",",
                "choices": [",", ";", "\t", "|"],
            }
            opts["encoding"] = {
                "type": "select",
                "label": "Encoding",
                "default": "utf-8",
                "choices": ["utf-8", "latin-1", "utf-16"],
            }
        if target_format == "json":
            opts["orient"] = {
                "type": "select",
                "label": "JSON Orientation",
                "default": "records",
                "choices": ["records", "columns", "index", "values"],
            }
            opts["indent"] = {
                "type": "slider",
                "label": "JSON Indent",
                "default": 2,
                "min": 0,
                "max": 8,
            }
        return opts

    def preview(self, file_bytes: bytes, fmt: str) -> str:
        try:
            if fmt == "xlsx":
                wb = load_workbook(io.BytesIO(file_bytes), read_only=True)
                sheets_info = []
                for sheet_name in wb.sheetnames:
                    ws = wb[sheet_name]
                    rows = list(ws.iter_rows(max_row=10, values_only=True))
                    if rows:
                        header = " | ".join(str(c or "") for c in rows[0])
                        data_rows = [
                            " | ".join(str(c or "") for c in row)
                            for row in rows[1:6]
                        ]
                        sheets_info.append(
                            f"Sheet: {sheet_name}\n{header}\n" + "\n".join(data_rows)
                        )
                wb.close()
                return "\n\n".join(sheets_info) if sheets_info else "[Empty workbook]"
            elif fmt == "csv":
                text = file_bytes.decode("utf-8", errors="replace")
                lines = text.split("\n")[:20]
                return "\n".join(lines)
            elif fmt == "json":
                text = file_bytes.decode("utf-8", errors="replace")
                data = json.loads(text)
                return json.dumps(data, indent=2)[:3000]
            elif fmt == "txt":
                text = file_bytes.decode("utf-8", errors="replace")
                return text[:3000]
        except Exception as e:
            return f"[Preview unavailable: {e}]"
        return "[Preview not available]"

    # --- Private conversion methods ---

    def _read_xlsx(self, data: bytes, options: Dict) -> Dict[str, pd.DataFrame]:
        sheet_opt = options.get("sheet_name", "first")
        if sheet_opt == "all":
            dfs = pd.read_excel(io.BytesIO(data), sheet_name=None, engine="openpyxl")
        else:
            df = pd.read_excel(io.BytesIO(data), engine="openpyxl")
            dfs = {"Sheet1": df}
        return dfs

    def _xlsx_to_csv(self, data: bytes, options: Dict) -> bytes:
        dfs = self._read_xlsx(data, options)
        delimiter = options.get("delimiter", ",")
        encoding = options.get("encoding", "utf-8")
        parts = []
        for name, df in dfs.items():
            if len(dfs) > 1:
                parts.append(f"# Sheet: {name}")
            parts.append(df.to_csv(index=False, sep=delimiter))
        return "\n".join(parts).encode(encoding)

    def _xlsx_to_json(self, data: bytes, options: Dict) -> bytes:
        dfs = self._read_xlsx(data, options)
        orient = options.get("orient", "records")
        indent = options.get("indent", 2)
        if len(dfs) == 1:
            df = list(dfs.values())[0]
            result = df.to_json(orient=orient, indent=indent, date_format="iso")
        else:
            result = json.dumps(
                {name: json.loads(df.to_json(orient=orient, date_format="iso"))
                 for name, df in dfs.items()},
                indent=indent,
            )
        return result.encode("utf-8")

    def _xlsx_to_html(self, data: bytes, options: Dict) -> bytes:
        dfs = self._read_xlsx(data, options)
        html_parts = [
            "<!DOCTYPE html><html><head><meta charset='utf-8'>",
            "<title>Converted Spreadsheet</title>",
            "<style>table{border-collapse:collapse;margin:20px 0;} th,td{border:1px solid #ddd;padding:8px;text-align:left;} th{background:#f4f4f4;font-weight:bold;} tr:nth-child(even){background:#f9f9f9;}</style>",
            "</head><body>",
        ]
        for name, df in dfs.items():
            if len(dfs) > 1:
                html_parts.append(f"<h2>{name}</h2>")
            html_parts.append(df.to_html(index=False, classes="data-table"))
        html_parts.append("</body></html>")
        return "\n".join(html_parts).encode("utf-8")

    def _xlsx_to_txt(self, data: bytes, options: Dict) -> bytes:
        dfs = self._read_xlsx(data, options)
        parts = []
        for name, df in dfs.items():
            if len(dfs) > 1:
                parts.append(f"=== Sheet: {name} ===")
            parts.append(df.to_string(index=False))
        return "\n\n".join(parts).encode("utf-8")

    def _csv_to_xlsx(self, data: bytes, options: Dict) -> bytes:
        delimiter = options.get("delimiter", ",")
        encoding = options.get("encoding", "utf-8")
        text = data.decode(encoding, errors="replace")
        df = pd.read_csv(io.StringIO(text), sep=delimiter)
        buf = io.BytesIO()
        df.to_excel(buf, index=False, engine="openpyxl")
        return buf.getvalue()

    def _csv_to_json(self, data: bytes, options: Dict) -> bytes:
        delimiter = options.get("delimiter", ",")
        encoding = options.get("encoding", "utf-8")
        orient = options.get("orient", "records")
        indent = options.get("indent", 2)
        text = data.decode(encoding, errors="replace")
        df = pd.read_csv(io.StringIO(text), sep=delimiter)
        return df.to_json(orient=orient, indent=indent, date_format="iso").encode("utf-8")

    def _csv_to_html(self, data: bytes, options: Dict) -> bytes:
        delimiter = options.get("delimiter", ",")
        encoding = options.get("encoding", "utf-8")
        text = data.decode(encoding, errors="replace")
        df = pd.read_csv(io.StringIO(text), sep=delimiter)
        html = df.to_html(index=False, classes="data-table")
        full_html = f"<!DOCTYPE html><html><head><meta charset='utf-8'><style>table{{border-collapse:collapse;}} th,td{{border:1px solid #ddd;padding:8px;}}</style></head><body>{html}</body></html>"
        return full_html.encode("utf-8")

    def _json_to_xlsx(self, data: bytes, options: Dict) -> bytes:
        text = data.decode("utf-8", errors="replace")
        parsed = json.loads(text)
        if isinstance(parsed, list):
            df = pd.DataFrame(parsed)
        elif isinstance(parsed, dict):
            # Try records-like first
            first_val = next(iter(parsed.values()), None)
            if isinstance(first_val, list):
                df = pd.DataFrame(parsed)
            else:
                df = pd.DataFrame([parsed])
        else:
            raise ValueError("JSON must be an array or object")
        buf = io.BytesIO()
        df.to_excel(buf, index=False, engine="openpyxl")
        return buf.getvalue()

    def _json_to_csv(self, data: bytes, options: Dict) -> bytes:
        delimiter = options.get("delimiter", ",")
        encoding = options.get("encoding", "utf-8")
        text = data.decode("utf-8", errors="replace")
        parsed = json.loads(text)
        if isinstance(parsed, list):
            df = pd.DataFrame(parsed)
        elif isinstance(parsed, dict):
            first_val = next(iter(parsed.values()), None)
            if isinstance(first_val, list):
                df = pd.DataFrame(parsed)
            else:
                df = pd.DataFrame([parsed])
        else:
            raise ValueError("JSON must be an array or object")
        return df.to_csv(index=False, sep=delimiter).encode(encoding)
