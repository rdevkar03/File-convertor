"""
Plugin auto-discovery registry for file format converters.

Automatically discovers all BaseConverter subclasses in the converters/ package
and builds a registry mapping (source_format, target_format) -> converter instance.
"""

import importlib
import inspect
import pkgutil
from typing import Dict, Tuple, Optional

from .base import BaseConverter

# Global registry: (source_fmt, target_fmt) -> converter instance
REGISTRY: Dict[Tuple[str, str], BaseConverter] = {}

# All discovered converter instances
_converters: list[BaseConverter] = []


def _discover_converters():
    """Scan this package for BaseConverter subclasses and register them."""
    package = importlib.import_module(__package__)
    for importer, modname, ispkg in pkgutil.iter_modules(package.__path__):
        if modname == "base":
            continue
        module = importlib.import_module(f"{__package__}.{modname}")
        for name, obj in inspect.getmembers(module, inspect.isclass):
            if issubclass(obj, BaseConverter) and obj is not BaseConverter:
                instance = obj()
                _converters.append(instance)
                for src, tgt in instance.supported_conversions():
                    REGISTRY[(src.lower(), tgt.lower())] = instance


def get_converter(source_format: str, target_format: str) -> Optional[BaseConverter]:
    """Get the converter instance for a given format pair."""
    return REGISTRY.get((source_format.lower(), target_format.lower()))


def get_supported_targets(source_format: str) -> list[str]:
    """Get all target formats available for a given source format."""
    return sorted(
        tgt for src, tgt in REGISTRY if src == source_format.lower()
    )


def get_all_source_formats() -> list[str]:
    """Get all source formats that have at least one converter."""
    return sorted(set(src for src, tgt in REGISTRY))


def get_all_conversions() -> list[Tuple[str, str]]:
    """Get all registered (source, target) pairs."""
    return sorted(REGISTRY.keys())


# Auto-discover on import
_discover_converters()
