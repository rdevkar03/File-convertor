import io
from typing import Dict, List, Tuple, Any, Optional

from docx import Document
import markdown as md_lib
from bs4 import BeautifulSoup

from .base import BaseConverter


class DocxConverter(BaseConverter):
    """Converter for Word documents. Supports DOCX <-> TXT, HTML, MD."""

    def supported_conversions(self) -> List[Tuple[str, str]]:
        return [
            ("docx", "txt"),
            ("docx", "html"),
            ("docx", "md"),
            ("docx", "pdf"),
            ("txt", "docx"),
            ("html", "docx"),
            ("md", "docx"),
        ]

    def convert(
        self,
        input_bytes: bytes,
        source_format: str,
        target_format: str,
        options: Optional[Dict[str, Any]] = None,
    ) -> bytes:
        options = options or {}
        key = (source_format, target_format)
        dispatch = {
            ("docx", "txt"): self._docx_to_txt,
            ("docx", "html"): self._docx_to_html,
            ("docx", "md"): self._docx_to_md,
            ("docx", "pdf"): self._docx_to_pdf,
            ("txt", "docx"): self._txt_to_docx,
            ("html", "docx"): self._html_to_docx,
            ("md", "docx"): self._md_to_docx,
        }
        handler = dispatch.get(key)
        if not handler:
            raise ValueError(f"Unsupported conversion: {source_format} -> {target_format}")
        return handler(input_bytes, options)

    def get_compression_options(
        self, source_format: str, target_format: str
    ) -> Dict[str, Any]:
        opts: Dict[str, Any] = {}
        if target_format == "docx":
            opts["font_name"] = {
                "type": "select",
                "label": "Font",
                "default": "Calibri",
                "choices": ["Calibri", "Arial", "Times New Roman", "Courier New"],
            }
            opts["font_size"] = {
                "type": "slider",
                "label": "Font Size (pt)",
                "default": 11,
                "min": 8,
                "max": 24,
            }
        if target_format in ("txt", "csv"):
            opts["encoding"] = {
                "type": "select",
                "label": "Text Encoding",
                "default": "utf-8",
                "choices": ["utf-8", "ascii", "latin-1", "utf-16"],
            }
        return opts

    def preview(self, file_bytes: bytes, fmt: str) -> str:
        if fmt == "docx":
            try:
                doc = Document(io.BytesIO(file_bytes))
                lines = []
                for i, para in enumerate(doc.paragraphs[:50]):
                    if para.text.strip():
                        lines.append(para.text)
                preview = "\n".join(lines)
                total = len(doc.paragraphs)
                if total > 50:
                    preview += f"\n\n... and {total - 50} more paragraph(s)"
                return preview
            except Exception as e:
                return f"[Preview unavailable: {e}]"
        elif fmt in ("txt", "md", "html"):
            text = file_bytes.decode("utf-8", errors="replace")
            return text[:3000] + ("..." if len(text) > 3000 else "")
        return "[Preview not available]"

    # --- Private conversion methods ---

    def _docx_to_txt(self, data: bytes, options: Dict) -> bytes:
        doc = Document(io.BytesIO(data))
        encoding = options.get("encoding", "utf-8")
        text = "\n".join(p.text for p in doc.paragraphs)
        return text.encode(encoding, errors="replace")

    def _docx_to_html(self, data: bytes, options: Dict) -> bytes:
        doc = Document(io.BytesIO(data))
        html_parts = [
            "<!DOCTYPE html><html><head><meta charset='utf-8'>",
            "<title>Converted Document</title>",
            "<style>body{font-family:sans-serif;margin:40px;line-height:1.6;} h1,h2,h3{color:#333;}</style>",
            "</head><body>",
        ]
        for para in doc.paragraphs:
            style = para.style.name.lower() if para.style else ""
            text = para.text.strip()
            if not text:
                continue
            if "heading 1" in style:
                html_parts.append(f"<h1>{text}</h1>")
            elif "heading 2" in style:
                html_parts.append(f"<h2>{text}</h2>")
            elif "heading 3" in style:
                html_parts.append(f"<h3>{text}</h3>")
            else:
                html_parts.append(f"<p>{text}</p>")
        html_parts.append("</body></html>")
        return "\n".join(html_parts).encode("utf-8")

    def _docx_to_md(self, data: bytes, options: Dict) -> bytes:
        doc = Document(io.BytesIO(data))
        lines = []
        for para in doc.paragraphs:
            style = para.style.name.lower() if para.style else ""
            text = para.text.strip()
            if not text:
                lines.append("")
                continue
            if "heading 1" in style:
                lines.append(f"# {text}")
            elif "heading 2" in style:
                lines.append(f"## {text}")
            elif "heading 3" in style:
                lines.append(f"### {text}")
            elif "list" in style:
                lines.append(f"- {text}")
            else:
                lines.append(text)
            lines.append("")
        return "\n".join(lines).encode("utf-8")

    def _docx_to_pdf(self, data: bytes, options: Dict) -> bytes:
        from fpdf import FPDF

        doc = Document(io.BytesIO(data))
        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.add_page()
        pdf.set_font("Helvetica", size=11)

        for para in doc.paragraphs:
            style = para.style.name.lower() if para.style else ""
            text = para.text.strip()
            if not text:
                pdf.ln(4)
                continue
            if "heading 1" in style:
                pdf.set_font("Helvetica", "B", 18)
                pdf.cell(0, 10, text, new_x="LMARGIN", new_y="NEXT")
                pdf.set_font("Helvetica", size=11)
            elif "heading 2" in style:
                pdf.set_font("Helvetica", "B", 14)
                pdf.cell(0, 8, text, new_x="LMARGIN", new_y="NEXT")
                pdf.set_font("Helvetica", size=11)
            else:
                pdf.multi_cell(0, 6, text)
            pdf.ln(2)

        return pdf.output()

    def _txt_to_docx(self, data: bytes, options: Dict) -> bytes:
        text = data.decode("utf-8", errors="replace")
        doc = Document()

        font_name = options.get("font_name", "Calibri")
        font_size = options.get("font_size", 11)

        style = doc.styles["Normal"]
        style.font.name = font_name
        from docx.shared import Pt
        style.font.size = Pt(font_size)

        for line in text.split("\n"):
            doc.add_paragraph(line)

        buf = io.BytesIO()
        doc.save(buf)
        return buf.getvalue()

    def _html_to_docx(self, data: bytes, options: Dict) -> bytes:
        soup = BeautifulSoup(data.decode("utf-8", errors="replace"), "html.parser")
        doc = Document()

        font_name = options.get("font_name", "Calibri")
        font_size = options.get("font_size", 11)
        style = doc.styles["Normal"]
        style.font.name = font_name
        from docx.shared import Pt
        style.font.size = Pt(font_size)

        for element in soup.find_all(["h1", "h2", "h3", "h4", "p", "li"]):
            text = element.get_text(strip=True)
            if not text:
                continue
            tag = element.name
            if tag == "h1":
                doc.add_heading(text, level=1)
            elif tag == "h2":
                doc.add_heading(text, level=2)
            elif tag == "h3":
                doc.add_heading(text, level=3)
            elif tag == "li":
                doc.add_paragraph(text, style="List Bullet")
            else:
                doc.add_paragraph(text)

        buf = io.BytesIO()
        doc.save(buf)
        return buf.getvalue()

    def _md_to_docx(self, data: bytes, options: Dict) -> bytes:
        html = md_lib.markdown(data.decode("utf-8", errors="replace"))
        return self._html_to_docx(html.encode("utf-8"), options)
