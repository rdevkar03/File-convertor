import io
from typing import Dict, List, Tuple, Any, Optional

import markdown as md_lib
from bs4 import BeautifulSoup
import chardet

from .base import BaseConverter


class TextConverter(BaseConverter):
    """Converter for plain text and Markdown files."""

    def supported_conversions(self) -> List[Tuple[str, str]]:
        return [
            ("txt", "md"),
            ("txt", "html"),
            ("md", "html"),
            ("md", "txt"),
        ]

    def convert(
        self,
        input_bytes: bytes,
        source_format: str,
        target_format: str,
        options: Optional[Dict[str, Any]] = None,
    ) -> bytes:
        options = options or {}
        key = (source_format, target_format)
        dispatch = {
            ("txt", "md"): self._txt_to_md,
            ("txt", "html"): self._txt_to_html,
            ("md", "html"): self._md_to_html,
            ("md", "txt"): self._md_to_txt,
        }
        handler = dispatch.get(key)
        if not handler:
            raise ValueError(f"Unsupported conversion: {source_format} -> {target_format}")
        return handler(input_bytes, options)

    def get_compression_options(
        self, source_format: str, target_format: str
    ) -> Dict[str, Any]:
        opts: Dict[str, Any] = {}
        opts["encoding"] = {
            "type": "select",
            "label": "Output Encoding",
            "default": "utf-8",
            "choices": ["utf-8", "ascii", "latin-1", "utf-16"],
        }
        if target_format == "html":
            opts["include_css"] = {
                "type": "checkbox",
                "label": "Include default CSS styling",
                "default": True,
            }
            opts["syntax_highlight"] = {
                "type": "checkbox",
                "label": "Enable code syntax highlighting (Markdown)",
                "default": False,
            }
        if source_format == "txt" and target_format == "md":
            opts["auto_headers"] = {
                "type": "checkbox",
                "label": "Auto-detect headers (ALL CAPS lines)",
                "default": True,
            }
        return opts

    def preview(self, file_bytes: bytes, fmt: str) -> str:
        detected = chardet.detect(file_bytes)
        encoding = detected.get("encoding", "utf-8") or "utf-8"
        text = file_bytes.decode(encoding, errors="replace")
        return text[:3000] + ("..." if len(text) > 3000 else "")

    # --- Private conversion methods ---

    def _decode(self, data: bytes) -> str:
        detected = chardet.detect(data)
        encoding = detected.get("encoding", "utf-8") or "utf-8"
        return data.decode(encoding, errors="replace")

    def _encode(self, text: str, options: Dict) -> bytes:
        encoding = options.get("encoding", "utf-8")
        return text.encode(encoding, errors="replace")

    def _txt_to_md(self, data: bytes, options: Dict) -> bytes:
        text = self._decode(data)
        auto_headers = options.get("auto_headers", True)
        lines = text.split("\n")
        md_lines = []

        for line in lines:
            stripped = line.strip()
            if auto_headers and stripped and stripped == stripped.upper() and stripped.isalpha() and len(stripped) > 2:
                md_lines.append(f"## {stripped.title()}")
            elif stripped == "":
                md_lines.append("")
            else:
                md_lines.append(stripped)

        return self._encode("\n".join(md_lines), options)

    def _txt_to_html(self, data: bytes, options: Dict) -> bytes:
        text = self._decode(data)
        include_css = options.get("include_css", True)

        paragraphs = text.split("\n\n")
        body_parts = []
        for para in paragraphs:
            lines = para.strip().split("\n")
            content = "<br>".join(lines)
            if content:
                body_parts.append(f"<p>{content}</p>")

        css = ""
        if include_css:
            css = "<style>body{font-family:sans-serif;margin:40px;line-height:1.6;max-width:800px;} p{margin:0 0 1em 0;}</style>"

        html = f"<!DOCTYPE html><html><head><meta charset='utf-8'><title>Converted Text</title>{css}</head><body>\n" + "\n".join(body_parts) + "\n</body></html>"
        return self._encode(html, options)

    def _md_to_html(self, data: bytes, options: Dict) -> bytes:
        text = self._decode(data)
        include_css = options.get("include_css", True)
        extensions = ["tables", "fenced_code", "toc"]
        if options.get("syntax_highlight", False):
            extensions.append("codehilite")

        html_body = md_lib.markdown(text, extensions=extensions)

        css = ""
        if include_css:
            css = "<style>body{font-family:sans-serif;margin:40px;line-height:1.6;max-width:800px;} code{background:#f4f4f4;padding:2px 6px;border-radius:3px;} pre{background:#f4f4f4;padding:16px;border-radius:6px;overflow-x:auto;} table{border-collapse:collapse;} th,td{border:1px solid #ddd;padding:8px;}</style>"

        html = f"<!DOCTYPE html><html><head><meta charset='utf-8'><title>Converted Markdown</title>{css}</head><body>\n{html_body}\n</body></html>"
        return self._encode(html, options)

    def _md_to_txt(self, data: bytes, options: Dict) -> bytes:
        text = self._decode(data)
        html = md_lib.markdown(text)
        soup = BeautifulSoup(html, "html.parser")
        plain = soup.get_text(separator="\n")
        return self._encode(plain, options)
