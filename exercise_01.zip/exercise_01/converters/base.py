from abc import ABC, abstractmethod
from typing import Dict, List, Tuple, Any, Optional


class BaseConverter(ABC):
    """Abstract base class for all file format converters.

    To create a new converter plugin, subclass this and implement all abstract methods.
    Drop the file into the converters/ directory and it will be auto-discovered.
    """

    @abstractmethod
    def supported_conversions(self) -> List[Tuple[str, str]]:
        """Return list of (source_format, target_format) pairs this converter handles.

        Example: [("pdf", "txt"), ("pdf", "docx"), ("docx", "pdf")]
        """
        ...

    @abstractmethod
    def convert(
        self,
        input_bytes: bytes,
        source_format: str,
        target_format: str,
        options: Optional[Dict[str, Any]] = None,
    ) -> bytes:
        """Convert file bytes from source_format to target_format.

        Args:
            input_bytes: Raw bytes of the source file.
            source_format: File extension without dot (e.g. "pdf").
            target_format: Desired output extension without dot.
            options: Optional dict of conversion options (quality, encoding, etc.).

        Returns:
            Converted file as bytes.
        """
        ...

    @abstractmethod
    def get_compression_options(
        self, source_format: str, target_format: str
    ) -> Dict[str, Any]:
        """Return available compression/quality options for a conversion pair.

        Returns a dict where keys are option names and values are dicts describing
        each option:
            {
                "option_name": {
                    "type": "slider" | "select" | "checkbox" | "number",
                    "label": "Human-readable label",
                    "default": <default_value>,
                    "min": <min_value>,       # for slider/number
                    "max": <max_value>,       # for slider/number
                    "choices": [<values>],    # for select
                }
            }
        """
        ...

    @abstractmethod
    def preview(self, file_bytes: bytes, fmt: str) -> str:
        """Generate a text preview of the file for display in the UI.

        Args:
            file_bytes: Raw bytes of the file.
            fmt: File format extension without dot.

        Returns:
            String representation suitable for display.
        """
        ...

    def validate(self, input_bytes: bytes, source_format: str) -> bool:
        """Optional validation that the input bytes match the expected format.

        Override in subclasses for stricter validation. Default returns True.
        """
        return True
