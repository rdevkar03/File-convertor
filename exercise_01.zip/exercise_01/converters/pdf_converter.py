import io
from typing import Dict, List, Tuple, Any, Optional

from PyPDF2 import PdfReader, PdfWriter
from fpdf import FPDF
import pdfplumber

from .base import BaseConverter


class PdfConverter(BaseConverter):
    """Converter for PDF documents. Supports PDF <-> TXT, PDF <-> HTML."""

    def supported_conversions(self) -> List[Tuple[str, str]]:
        return [
            ("pdf", "txt"),
            ("pdf", "html"),
            ("pdf", "csv"),
            ("txt", "pdf"),
            ("html", "pdf"),
            ("md", "pdf"),
        ]

    def convert(
        self,
        input_bytes: bytes,
        source_format: str,
        target_format: str,
        options: Optional[Dict[str, Any]] = None,
    ) -> bytes:
        options = options or {}

        if source_format == "pdf" and target_format == "txt":
            return self._pdf_to_txt(input_bytes, options)
        elif source_format == "pdf" and target_format == "html":
            return self._pdf_to_html(input_bytes, options)
        elif source_format == "pdf" and target_format == "csv":
            return self._pdf_to_csv(input_bytes, options)
        elif source_format == "txt" and target_format == "pdf":
            return self._txt_to_pdf(input_bytes, options)
        elif source_format == "html" and target_format == "pdf":
            return self._html_to_pdf(input_bytes, options)
        elif source_format == "md" and target_format == "pdf":
            return self._md_to_pdf(input_bytes, options)
        raise ValueError(f"Unsupported conversion: {source_format} -> {target_format}")

    def get_compression_options(
        self, source_format: str, target_format: str
    ) -> Dict[str, Any]:
        opts: Dict[str, Any] = {}
        if target_format == "pdf":
            opts["font_size"] = {
                "type": "slider",
                "label": "Font Size",
                "default": 12,
                "min": 8,
                "max": 24,
            }
            opts["page_margin"] = {
                "type": "slider",
                "label": "Page Margin (mm)",
                "default": 15,
                "min": 5,
                "max": 30,
            }
        if source_format == "pdf" and target_format == "txt":
            opts["page_separator"] = {
                "type": "checkbox",
                "label": "Add page separators",
                "default": True,
            }
        return opts

    def preview(self, file_bytes: bytes, fmt: str) -> str:
        if fmt == "pdf":
            try:
                with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
                    pages = []
                    for i, page in enumerate(pdf.pages[:3]):
                        text = page.extract_text() or "[No extractable text]"
                        pages.append(f"--- Page {i + 1} ---\n{text}")
                    preview_text = "\n\n".join(pages)
                    if len(pdf.pages) > 3:
                        preview_text += f"\n\n... and {len(pdf.pages) - 3} more page(s)"
                    return preview_text
            except Exception as e:
                return f"[Preview unavailable: {e}]"
        elif fmt == "txt":
            text = file_bytes.decode("utf-8", errors="replace")
            return text[:3000] + ("..." if len(text) > 3000 else "")
        return "[Preview not available for this format]"

    # --- Private conversion methods ---

    def _pdf_to_txt(self, data: bytes, options: Dict) -> bytes:
        separator = "\n\n--- Page Break ---\n\n" if options.get("page_separator", True) else "\n\n"
        with pdfplumber.open(io.BytesIO(data)) as pdf:
            texts = []
            for page in pdf.pages:
                text = page.extract_text() or ""
                texts.append(text)
        return separator.join(texts).encode("utf-8")

    def _pdf_to_html(self, data: bytes, options: Dict) -> bytes:
        with pdfplumber.open(io.BytesIO(data)) as pdf:
            html_parts = [
                "<!DOCTYPE html><html><head><meta charset='utf-8'>",
                "<title>Converted PDF</title>",
                "<style>body{font-family:sans-serif;margin:40px;} .page{margin-bottom:30px; padding:20px; border-bottom:1px solid #ccc;}</style>",
                "</head><body>",
            ]
            for i, page in enumerate(pdf.pages):
                text = page.extract_text() or ""
                paragraphs = text.split("\n")
                html_parts.append(f'<div class="page"><h3>Page {i + 1}</h3>')
                for para in paragraphs:
                    if para.strip():
                        html_parts.append(f"<p>{para}</p>")
                html_parts.append("</div>")
            html_parts.append("</body></html>")
        return "\n".join(html_parts).encode("utf-8")

    def _pdf_to_csv(self, data: bytes, options: Dict) -> bytes:
        import csv
        output = io.StringIO()
        writer = csv.writer(output)
        with pdfplumber.open(io.BytesIO(data)) as pdf:
            for page in pdf.pages:
                tables = page.extract_tables()
                for table in tables:
                    for row in table:
                        writer.writerow([cell or "" for cell in row])
        return output.getvalue().encode("utf-8")

    def _txt_to_pdf(self, data: bytes, options: Dict) -> bytes:
        text = data.decode("utf-8", errors="replace")
        font_size = options.get("font_size", 12)
        margin = options.get("page_margin", 15)

        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=margin)
        pdf.add_page()
        pdf.set_font("Helvetica", size=font_size)

        for line in text.split("\n"):
            pdf.cell(0, font_size * 0.5, line, new_x="LMARGIN", new_y="NEXT")

        return pdf.output()

    def _html_to_pdf(self, data: bytes, options: Dict) -> bytes:
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(data.decode("utf-8", errors="replace"), "html.parser")
        text = soup.get_text(separator="\n")
        return self._txt_to_pdf(text.encode("utf-8"), options)

    def _md_to_pdf(self, data: bytes, options: Dict) -> bytes:
        import markdown

        html = markdown.markdown(data.decode("utf-8", errors="replace"))
        return self._html_to_pdf(html.encode("utf-8"), options)
